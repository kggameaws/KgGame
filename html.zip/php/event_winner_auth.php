<!DOCTYPE html>
<html>
<head>
    <title>KG GAME</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Google WEB Font URL : https://fonts.google.com/?subset=korean&selection.family=Nanum+Gothic -->
    <!-- Nanum 고딕체중 마음에 드는거 선택 후 해당 링크를 HTML 코드에 삽입 -->
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    <style>
    .navbar {
        font-size: 15px;
        margin-bottom: 0;
        border-radius: 0;
    }
    .carousel-inner > .item > img {
        width:1200px;
        height:600px;
    }
    .modal-content {
        font-size: 15px; 
        margin: 0;
        padding: 0;
    }
    .navbar-brand {
        background-color: color #1d1d1d;
    }
    </style>

</head>

<body style="background-color: rgb(23, 52, 88); font-family: 'Nanum Gothic', sans-serif;">
    <!-- Navigation Bar Container -->
    <div class="container">
    <div class="row">
        <div class="col-sm-12">   
        <nav class="navbar navbar-inverse">
            <div class="container-fulid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#MyNav">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                        
                    </button>
                    <a class="navbar-brand" href="../index_auth.html">
                        <img style="max-width:180px; margin-top: -13px;" src="../images/kglogo3.png">
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="MyNav">
                <ul class="nav navbar-nav">
                    <li><a href="../index_auth.html">HOME</a></li>
                    <li><a href="../Game_info_auth.html">게임소개</a></li>
                    <li><a href="../community_auth.html">커뮤니티</a></li>
                    <li><a href="./event_running_auth.php">이벤트</a></li>
                    <li><a href="#">내 계정</a></li>
    
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">전체보기 <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="https://www.ubisoft.com/en-gb/game/the-division/the-division-2" target="_blank">Division</a></li>
                            <li><a href="https://lostark.game.onstove.com/Main" target="_blank">Lostark</a></li>
                            <li><a href="https://www.paydaythegame.com/payday2/" target="_blank">Payday2</a></li>
                        </ul>
                    </li>
                </ul>

                <ul class="nav navbar-nav navbar-right">
                    <li><a href="./logout.php"><span class="glyphicon glyphicon-log-out"></span>  LOGOUT</a></li>

                </ul>
            </div>
        </nav>
        </div>
    </div>
    </div><br>

    <!-- Carousel Container
    <div class="container">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0"></li>
            <li data-target="#myCarousel" data-slide-to="1" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>

        <div class="carousel-inner">
            <div class="item">
                <img src="../images/carousel_1.jpg" alt="Laptop_1">
                <div class="carousel-caption">
                    <h3><strong>Best Laptop Customize</strong></h3>
                    <h4>Laptop Touch Pad</h4>
                </div>
            </div>

            <div class="item active">
                <img src="../images/carousel_2.jpg" alt="Laptop_2">
                <div class="carousel-caption">
                    <h3><strong>Best Laptop Customize</strong></h3>
                    <h4>Laptop Key Skin</h4>
                </div>
            </div>

            <div class="item">
                <img src="../images/carousel_3.jpg" alt="Laptop_3">
                <div class="carousel-caption">
                    <h3><strong>Best Laptop Customize</strong></h3>
                    <h4>Laptop Touch Pad</h4>
                </div>
            </div>
        </div>

        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
        </a>

        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span> 
        </a>
    </div>
    </div>
    <br><br> -->

    <!-- Board Select -->
    <div class="container">
    <h2 style="color:#FFFFFF">이벤트</h2>
    <br><br>
    <!-- 전체 TAB Menu 구성 -->
    <!-- tab-Menu href와 tab-content ID값은 반드시 동일하게 구성 -->
    <!-- Menu와 Content를 연결 -->
        <ul class="nav nav-tabs" style="font-size:13pt;">
            <li class="col-sm-4 text-center"><a href="./event_running_auth.php">진행 중인 이벤트</a></li>
            <li class="col-sm-4 text-center"><a href="./event_closed_auth.php">지난 이벤트</a></li>
            <li class="active col-sm-4 text-center"><a href="./event_winner_auth.php">당첨자 발표</a></li>
        </ul>
    </div>

    <!-- Board_list -->
    <div class="container">
    <br><br>
    <table class="table">
        <thead>
            <tr style="font-size:12pt;">
                <th class="col-sm-1"></th>
                <th class="col-sm-7"></th>
                <th class="col-sm-3"></th>
                <th class="col-sm-1"></th>
            </tr>
        </thead>
        <tbody>
        <?php
                require_once("./db_con.php");
                $board_list_sql = "SELECT * FROM event_winner";
                $total_row_check = $conn->query($board_list_sql);
                $total_row = $total_row_check->num_rows;
    
                
                if (isset($_GET["page"])){
                    $start = $_GET["page"] * 20;
                    $page_sql = "SELECT * FROM event_winner ORDER BY No DESC LIMIT $start, 20";
        
                } else {
                    $page_sql = "SELECT * FROM event_winner ORDER BY No DESC LIMIT 20";
                }


                $result = $conn->query($page_sql);
                $flag = 1;
                while ($row = $result->fetch_assoc()){                  
                    if ($flag == 1 or $flag == 6) {
                        $st = "active";
                    }
                    else if ($flag == 2 or $flag == 7) {
                        $st = "active";
                    }
                    else if ($flag == 3 or $flag == 8) {
                        $st = "active";
                    }
                    else if ($flag == 4 or $flag == 9) {
                        $st = "active";
                    }
                    else {
                        $st = "active";
                    }                    
                    print "<tr class='$st'>";
                        print "<td></td>";
                        print "<td><a style='color: black;' href='./read_winner_auth.php?page=$row[no]'>$row[title]</a></td>";
                        print "<td style='text-align: right'>$row[date]</td>";
                        print "<td></td>";                        
                    print "</tr>";
                    $flag++;
                }
                
                $page_count = (int)($total_row / 20);
                if ($total_row % 20){ 
                    $page_count++;
                }
                $page_count--;

                if (isset($_GET['page'])) { 
                    $page = $_GET['page']; 
                } else $page = 0;
                ?>

                <tr>
                <td colspan=12>
                    <ul class="pager">
                    <div class='row'><br>
                        <!-- <div class='col-sm-5' style='text-align:left;'>
                        <li class="<?php if ($page == 0) echo 'disabled'; ?>">
                            <?php 
                                if ($page == 0) {
                                ?>
                                    <a>Previous</a>
                                <?php
                                } else {
                                ?>
                                    <a style='color: black;' href="./board.php?page=<?php echo ($page - 1); ?>">Previous</a>
                                <?php
                                }
                            ?>
                        </li>
                        </div> -->
                        
                        <div class='col-sm-12' style='text-align:center;'>
                        <li style='color: white; font-size:12pt;'><?php echo ($page + 1); ?></li>
                        </div>
                        
                        <!-- <div class='col-sm-5' style='text-align:right;'>
                        <li class="<?php if ($page >= $page_count ) echo 'disabled'; ?>">
                            <?php 
                                if ($page >= $page_count) {
                                ?>
                                    <a>Next</a>
                                <?php
                                } else {
                                ?>
                                    <a style='color: black;' href="./board.php?page=<?php echo ($page + 1); ?>">Next</a>
                                <?php
                                }
                            ?>
                        </li>
                        </div> -->

                        <div class='col-sm-1' style='text-align:center;'>
                            <li><a style='color: black;' data-toggle="modal" data-target="#Modal_Write">WRITE</a></li>    
                        </div>
                    </div>
                    </ul>
                    </td>
                </tr>
        </tbody>
    </table>
    <br>
    </div>

    <!-- WRITE Modal Container -->
    <div class="container">
    <div class="modal fade" id="Modal_Write" role="dialog">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">

        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">WRITE</h4>
        </div>

        <div class="modal-body">
        <div class="container">
        <form class="form-horizontal" action="./write_winner.php" method="POST" name="board_write-form"> 
            <div class="form-group">
                <label style="text-align:left" for="title" class="col-sm-2 control-label">TITLE</label>
                <div class="col-sm-6">
                    <input class="form-control" name="title" id="title" maxlength="100" type="text" autofocus placeholder="Title Input" required autocomplete="off" >
                </div>
            </div>

            <div class="form-group">
                <label style="text-align:left" for="pw" class="col-sm-2 control-label">CONTENT</label>
                <div class="col-sm-6">
                    <textarea class="form-control" rows="20" name = "content" id="content" maxlength="500" type="text" placeholder="Content Input" required autocomplete="off"></textarea>
                </div>
            </div>

            <div class="form-group">
                <label style="text-align:left" for="date" class="col-sm-2 control-label">DATE</label>
                <div class="col-sm-6">
                    <input class="form-control" name="date" id="date" maxlength="50" type="text" autofocus placeholder="Date Input" required autocomplete="off" >
                    
                </div>
            </div>
        </div>
        </div>

        <div class="modal-footer">
            <button type="submit" class="btn btn-default">WRITE</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">CANCEL</button>
        </div>
        </form>
        </div>
        </div>
    </div>
    </div>


    <!-- 고객센터 Container 
    <div id="contact" class="container">
    <h3>QUESTION</h3><br>
    <div class="row">
  
    <div class="col-md-4">
        <p><span class="glyphicon glyphicon-map-marker"></span> Seoul, KR</p>
        <p><span class="glyphicon glyphicon-phone"></span> Phone: +82 1544-0000</p>
        <p><span class="glyphicon glyphicon-envelope"></span> Email: cloud@cloud.com</p>
    </div>

    <div class="col-md-8">
        <div class="row">
        <form action="#" method="POST" name="service-form"> 
        <div class="col-sm-6 form-group">
            <input class="form-control" id="name" maxlength="10" placeholder="Name" type="text" required autocomplete="off">
        </div>
        <div class="col-sm-6 form-group">
            <input class="form-control" id="email" maxlength="40" placeholder="Email" type="email" required autocomplete="off">
        </div>
        </div>

        <textarea class="form-control" id="comments" maxlength="100" placeholder="Comment" rows="5" required autocomplete="off"></textarea>
        <br>
        <div class="row">
        <div class="col-md-12 form-group">
            <button class="btn pull-right btn-default" type="submit">SEND</button>
        </div>
        </div>
        </form>
    </div>
    </div> -->

    <!-- footer Container 
    <footer class="container text-center">
        <p><span>Cloud System Test Site<br>Copyright &copy; BlaBla</span></p>
    </footer> -->

    <!-- Login Modal Container -->
    <div class="container">
    <div class="modal fade" id="Modal_Login" role="dialog">
        <div class="modal-dialog">
        <div class="modal-content">

        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">LOGIN</h4>
        </div>

        <div class="modal-body">
        <div class="container">
        <form class="form-horizontal" action="./php/login.php" method="POST" name="login-form">

            <div class="form-group">
                <label style="text-align:left" for="login_id" class="col-sm-1 control-label">ID</label>
                <div class="col-sm-4">
                    <input class="form-control" name="login_id" id="login_id" maxlength="20" type="text" autofocus placeholder="User ID Here" required autocomplete="off" >
                </div>
            </div>

            <div class="form-group">
                <label style="text-align:left" for="login_pw" class="col-sm-1 control-label">PW</label>
                <div class="col-sm-4">
                    <input class="form-control" name="login_pw" id="login_pw" maxlength="30" type="password" autofocus placeholder="User Password Here" required autocomplete="off" >
                </div>
            </div>
        </div>
        </div>

        <div class="modal-footer">
            <button type="submit" class="btn btn-default">LOGIN</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">CANCEL</button>
        </div>
        </form>

        </div>
        </div>
    </div>
    </div>

    <!-- SignUP Modal Container -->
    <div class="container">
    <div class="modal fade" id="Modal_Signup" role="dialog">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">

        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">SIGN UP</h4>
        </div>

        <div class="modal-body">
        <div class="container">
        <form class="form-horizontal" action="./signup.php" method="POST" name="signup-form"> 
            <div class="form-group">
                <label style="text-align:left" for="id" class="col-sm-2 control-label">USER ID</label>
                <div class="col-sm-6">
                    <input class="form-control" name="id" id="id" maxlength="20" type="text" autofocus placeholder="User ID Here" required autocomplete="off" >
                </div>
            </div>

            <div class="form-group">
                <label style="text-align:left" for="pw" class="col-sm-2 control-label">USER PW</label>
                <div class="col-sm-6">
                    <input class="form-control" name="pw" id="pw" maxlength="30" type="password" placeholder="User Password Here" required autocomplete="off" >
                </div>
            </div>

            <div class="form-group">
                <label style="text-align:left" for="pw2" class="col-sm-2 control-label">RE-ENTER PW</label>
                <div class="col-sm-6">
                    <input class="form-control" name="pw2" id="pw2" maxlength="30" type="password" placeholder="User Repeat Password Here" required autocomplete="off" >
                </div>
            </div>

            <div class="form-group">
                <label style="text-align:left" for="name" class="col-sm-2 control-label">NAME</label>
                <div class="col-sm-6">
                    <input class="form-control" name="name" id="name" maxlength="20" type="text" placeholder="User Name Here" required autocomplete="off" >
                </div>
            </div>

            <div class="form-group">
                <label style="text-align:left" for="phone" class="col-sm-2 control-label">PHONE</label>
                <div class="col-sm-6">
                    <input class="form-control" name="phone" id="phone" maxlength="50" type="text" placeholder="User Phone Number Here" required autocomplete="off" >
                </div>
            </div>

            <div class="form-group">
                <label style="text-align:left" for="addr" class="col-sm-2 control-label">ADDRESS</label>
                <div class="col-sm-6">
                    <input class="form-control" name="addr" id="addr" maxlength="50" type="text" placeholder="User Address Here" required autocomplete="off" >
                </div>
            </div>

            <div class="form-group">
                <label style="text-align:left" for="mail" class="col-sm-2 control-label">E-Mail</label>
                <div class="col-sm-6">
                    <input class="form-control" name="mail" id="mail" maxlength="50" type="email" placeholder="User E-Mail Address Here" required autocomplete="off" >
                </div>
            </div>
        </div>
        </div>

        <div class="modal-footer">
            <button type="submit" class="btn btn-default">SIGN UP</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">CANCEL</button>
        </div>
        </form>
        </div>
        </div>
    </div>
    </div>

    <!-- footer Container -->
    <footer style="background-color: #1d1d1d;" class="container text-center">
        <div id="STORE" class="container text-center" >
        <br><br>
        <span style="font-size:20px; color: #cacaca;" class="glyphicon glyphicon-earphone"></span><a href="./QNA_auth.php" class="btn" style="color: #cacaca;">고객문의</a></span>
        <div style = "text-align:center;margin-bottom:100px;">
        <br><br>

        <p style="color: #cacaca;"> 
            <i class="fa fa-instagram" aria-hidden="true" style="color: #cacaca;"></i> 인스타그램&nbsp;&nbsp;
            <i class="fa fa-twitter" aria-hidden="true"></i> 트위터&nbsp;&nbsp;&nbsp;
            <i class="fa fa-youtube-play" aria-hidden="true"></i> 유튜브 
        </p>
        <br><br>

        <div style="font-size:12pt;"> 
            <span><a href="#" class="btn" style="color: #cacaca;">회사소개</a></span> | 
            <span><a href="#" class="btn" style="color: #cacaca;">이용약관</a></span> | 
            <span><a href="#" class="btn" style="color: #cacaca;">개인정보처리방침</a></span> | 
            <span><a href="#" class="btn" style="color: #cacaca;">청소년 보호 정책</a></span> | 
            <span><a href="#" class="btn" style="color: #cacaca;">커뮤니티 정책</a></span> | 
            <span><a href="#" class="btn" style="color: #cacaca;">운영정책</a></span> 
        </div>
        
        <hr style="border: solid 1px rgb(146, 146, 146); width: 850px;">  

        <div style="margin-top:10pt; color: #cacaca;"> 
            <p><span>상호 (주) KGGAME 사업자 등록번호 123-45-67890 통신판매업신고 제 2021-서울종로-1234호 사업자정보확인
                <br>주소 서울 종로구 돈화문로 26 단성사 4층 고객상담 1234-5678 팩스 02-1234-5678 이메일 kggame@kggame.com
                <br>Copyright &copy; KGGAME Corporation. All Rights Reserved.</span></p>
                <br>        
        </div> 
    </div>
    </footer>

</body>
</html>

