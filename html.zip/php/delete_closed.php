<?php
    // mysqli Class
    require_once("./db_con_master.php");
    $page = $_GET["page"];
    $delete_sql = "DELETE FROM event_closed WHERE no='$page'";
    $conn->query($delete_sql);

    $CNT = "SET @CNT=0";
    $conn->query($CNT);
    $Auto_Increment = "UPDATE event_closed SET no = @CNT:=@CNT+1";
    $conn->query($Auto_Increment);
    
    echo "<script>alert(\"정상적으로 삭제되었습니다.\");</script>";
    echo "<script>location.replace('./event_closed_auth.php');</script>";
?>
