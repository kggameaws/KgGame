<!DOCTYPE html>
<html>
<head>
    <title>KG GAME</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Google WEB Font URL : https://fonts.google.com/?subset=korean&selection.family=Nanum+Gothic -->
    <!-- Nanum 고딕체중 마음에 드는거 선택 후 해당 링크를 HTML 코드에 삽입 -->
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    <style>
    body { 
        background-color: rgb(23, 52, 88); 
    }
    .navbar {
        font-size: 15px;
        margin-bottom: 0;
        border-radius: 0;
    }
    .carousel-inner > .item > img {
        width:1200px;
        height:600px;
    }
    .modal-content {
        font-size: 15px; 
        margin: 0;
        padding: 0;
    }
    .navbar-brand {
        background-color:#1b1b1b
    }
    </style>

</head>

<body style="font-family: 'Nanum Gothic', sans-serif;">
    <!-- Navigation Bar Container -->
    <div class="container">
    <div class="row">
        <div class="col-sm-12">   
        <nav class="navbar navbar-inverse">
            <div class="container-fulid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#MyNav">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                        
                    </button>
                    <a class="navbar-brand" href="../index2.html">
                        <img style="max-width:180px; margin-top: -13px;" src="../images/kglogo3.png">
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="MyNav">
                <ul class="nav navbar-nav">
                    <li><a href="../index2.html">HOME</a></li>
                    <li><a href="../Game_info_2.html">게임소개</a></li>
                    <li><a href="../community_2.html">커뮤니티</a></li>
                    <li><a href="./event_running2.php">이벤트</a></li>
                    <li><a href="#">내 계정</a></li>

                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">전체보기 <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="https://www.ubisoft.com/en-gb/game/the-division/the-division-2" target="_blank">Division</a></li>
                            <li><a href="https://lostark.game.onstove.com/Main" target="_blank">Lostark</a></li>
                            <li><a href="https://www.paydaythegame.com/payday2/" target="_blank">Payday2</a></li>
                        </ul>
                    </li>
                </ul>

                <ul class="nav navbar-nav navbar-right">
                    <li><a href="./logout.php"><span class="glyphicon glyphicon-log-out"></span>  LOGOUT</a></li>
                </ul>
            </div>
        </nav>
        </div>
    </div>
    </div><br>
    
    <!-- Frequent QNA -->
    <div class="container">
         <h2 style="color:#FFFFFF">자주하는 질문 &nbsp;<span class="glyphicon glyphicon-question-sign"></span></h2></div>
    </div>

    <div class="container">
        <br>
            <div class="panel-group" id="Main">
                <div class="panel panel-default">
                    <div class="panel-heading">
                         <h2 class="panel-title">
                             <a data-toggle="collapse" data-parent="#Main" href="#List1">영웅/전설 등급의 카드를 획득하였으나 컬렉션에 활성화되지 않습니다.</a>
                         </h2>
                    </div>

                    <div id="List1" class="panel-collapse collapse in">
                    <div class="panel-body">
                      <h4 class="text-default">획득하신 영웅, 전설 등급의 변신, 마법인형 카드는 카드 획득 대기 상태로 먼저 적용됩니다.</h4><br>
                      <h5 class="text-default">이는 카드 뽑기, 합성, TJ쿠폰-변신에서 획득된 모든 경우에 적용되고 있는데요. </h5><br>
                      <h5 class="text-default">변신, 마법인형 카드 획득 대기 상태에서는 컬렉션 목록에 바로 추가되지 않으며,</h5>
                      <h5 class="text-default">게임 화면의 미니맵 왼쪽에 표시된 [카드 교체 바로가기] 아이콘을 터치하여 나오는 화면에서</h5>
                      <h5 class="text-default">획득하신 영웅, 전설 등급의 변신, 마법인형 카드는 카드 획득 대기 상태로 먼저 적용됩니다.</h5>
                      <h5 class="text-default">카드 교체 여부를 결정하신 후, [카드 확정] 키를 터치하셔야 컬렉션에 등록하실 수 있습니다.</h5><br>                
                      <h5 class="text-danger font-weight-bold">단, 카드 교체는 영웅, 전설 등급 카드 획득 시점으로부터 7일까지만 가능한 점 참고해주세요!</h5>
                    </div>
                    </div>
                </div>

                 <div class="panel panel-default">
                     <div class="panel-heading">
                         <h2 class="panel-title">
                              <a data-toggle="collapse" data-parent="#Main" href="#List2">64비트 적용 후 끊김(렉/지연) 현상을 겪고 있습니다.</a>
                         </h2>
                     </div>

                     <div id="List2" class="panel-collapse collapse">
                     <div class="panel-body">
                         <h5 class="text-default font-weight-bold">64비트 업데이트 후 끊김/렉 현상으로 플레이에 불편을 겪고 계실 때 도움이 될만한 설정방법 몇가지를 알려드립니다.</h5><br>
                         <h4 class="text-default font-weight-bold">1. 게임 내 옵션 : 그래픽 옵션 변경 </h4>
                         <h5 class="text-default">ⅰ. 데미지 효과 > 미니 기본 효과로 세팅</h5>
                          <h5 class="text-default">ⅱ. 해상도를 기존 이용하던 것보다 낮춰서 세팅</h5>
                           <h5 class="text-default">ⅲ. 전체 화면 모드보다는 창모드로 설정</h5>
                         <h5 class="text-default">ⅳ. 수직 동기화 체크 해제</h5>               
                         <h5 class="test-default">ⅴ. 품질에 배경, 이펙트 모두 낮게 설정</h5>
                         <h5 class="text-default">ⅵ. 스킬이펙트 투명도, 다른 캐릭터 투명 설정</h5>
                         <h5 class="text-default">ⅶ. 화면 흔들림 체크 해제</h5>               
                         <h5 class="test-default">ⅷ. 타격 실루엣 체크 해제</h5><br>
                          <h4 class="text-default font-weight-bold">2. 게임 내 옵션 : 게임 옵션 중 일부를 아래 항목과 같이 변경  </h4>
                          <img src="../images/QNA1.png" alt="QNA1"><br><br>
                          <h4 class="text-default font-weight-bold">3. PC 전원 설정 “고성능”으로 변경</h4>
                          <h5 class="text-default">  : 제어판 > 하드웨어 및 소리 > 전원 옵션 > 고성능 체크</h5>        
                          <img src="../images/QNA2.png" alt="QNA2"><br>
                      </div>
                      </div>
                 </div>

                 <div class="panel panel-default">
                     <div class="panel-heading">
                          <h2 class="panel-title">
                              <a data-toggle="collapse" data-parent="#Main" href="#List3">환불금액을 받지 못했습니다.</a>
                          </h2>
                      </div>

                      <div id="List3" class="panel-collapse collapse">
                      <div class="panel-body">
                          <h5 class="text-default font-weight-bold">일반적인 문제: </h5>
                          <h5 class="text-default">▶ 환불 후 금액이 입금되지 않았습니다.</h5>
                           <h5 class="text-default">▶ 결제취소 후 금액이 입금되지 않았습니다.</h5><br>
                           <h5 class="text-default">먼저, 일반적인 환불금액의 입금은 최대 3영업일 정도의 시간이 소요될 수 있습니다.</h5>
                          <h5 class="text-default">아직 환불금이 입금되지 않았다면, 환불 신청 후 아직 입금기간이 되지 않은 것은 아닌지 확인해 주시기 바랍니다.</h5>               
                          <h5 class="test-default">입금기간이 지났음에도 입금되지 않았다면 환불이 아닌 "결제취소"로 처리되었거나 "입금정보 불일치"로 인해 환불이 지연되고 있을 수 있습니다.</h5>
                          <h5 class="text-default">혹시라도 아래와 같은 상황이 아닌지 확인해 주시길 부탁 드립니다.</h5><br><br>             
                          <h4 class="test-default font-weight-bold">결제취소란?</h4>
                         <h5 class="text-default">별도의 환불금 입금이 아닌, 결제 내역이 취소되며 각 결제 수단 업체별로 절차가 진행 됩니다.</h5><br>
                          <h5 class="test-default font-weight-bold">KGgame 사이트에서 신용카드로 구매 하신 경우</h5>
                          <h5 class="text-default">∙ 결제 취소가 진행되며 3 ~ 7영업일 후 카드사에서 확인 가능</h5>                             
                          <h5 class="text-default">∙ 이미 카드사 납부가 완료된 상태에서도 각 카드사 별 처리</h5><br>          
                          <h5 class="test-default font-weight-bold">KGgame 사이트에서 실시간 계좌이체로 구매하신 경우</h5>                           
                         <h5 class="text-default">∙ 결제일로부터 60일이내 환불 요청 시, 결제취소로 진행되며 3영업일 내 결제한 계좌로 재 입금</h5><br>      
                          <h5 class="test-default font-weight-bold">KGgame 사이트에서 당월 ARS/휴대폰으로 구매 하신 경우</h5>                           
                         <h5 class="text-default">∙ 별도의 환불금 없이 익월 청구서에서 제외됨</h5><br><br>
                         <h4 class="test-default font-weight-bold">입금 정보 불일치란?</h4>
                          <h5 class="text-default">블리자드 사이트에서 당월 ARS/휴대폰으로 구매 하신 경우</h5>
                          <h5 class="test-default">계좌번호에 오타가 있는 잘못된 계좌일 경우로 환불 입금이 정상적으로 처리되지 않습니다</h5>
                         <h5 class="text-default">∙ 만약 위에 안내된 입금 기간이 지났고 결제취소 된 것도 아니나 환불 입금이 지연되고 있는 경우, “입금 정보”가 잘못 접수된 것은 아닌지 확인 부탁 드립니다.</h5>                             
                         <h5 class="text-default">∙ 이 경우, 별도의 메일을 발송해 드릴 예정입니다. 메일 확인 후 안내된 양식에 따라 계좌정보를 다시 보내주시길 부탁 드립니다. </h5>                         
                     </div>
                     </div>
                 </div>
            

                 <div class="panel panel-default">
                      <div class="panel-heading">
                            <h2 class="panel-title">
                                  <a data-toggle="collapse" data-parent="#Main" href="#List4">게임 중 상대 유저가 욕설을 사용했습니다. 신고는 어떻게 하나요?(불건전 언어 사용자 신고)</a>
                            </h2>
                     </div>
            

                     <div id="List4" class="panel-collapse collapse">
                     <div class="panel-body">
                          <h4 class="text-default font-weight-bold">게임 내에서 상대방으로부터 욕설이나 비방을 들었을 경우에는 plaync 공식 홈페이지 [고객지원]을 통해 접수가 가능합니다.</h4><br>
                           <h5 class="text-default"><span class="glyphicon glyphicon-exclamation-sign"></span>접수해주신 불량 이용자 신고의 경우, 최대한 빠른 시일 내에 조치를 취하도록 하겠으나,계정 제한과 같은 조치를 취하기 위해서는 객관적인 기록과 근거가 필요하기 때문에 다소 시간이 소요될 수 있습니다. </h5>
                         <h5 class="text-default"><span class="glyphicon glyphicon-exclamation-sign"></span>불건전 언어 사용은 운영 정책에 따라 아래와 같이 제재될 수 있습니다.</h5><br>
                         <h5 class="text-default">[ 1차 ] - [ (경고 3회 누적 시) 7일 계정 이용 제한 ] </h5>
                         <h5 class="text-default">[ 2차 ] - [ 30일 계정 이용 제한 ]</h5>
                         <h5 class="text-default">[ 3차 ] - [ 90일 계정 이용 제한 ]</h5><br>               
                         <h4 class="test-default font-weight-bold">불량이용자 신고는 화면 하단의 "고객문의"를 통해 접수하실 수 있습니다.</h4>   
                         <h5 class="test-danger font-weight-bold">※반드시 신고할 ID, 자세한 신고 내용을 기재하시길 바랍니다.</h5>  
                         <img src="../images/QNA3.png" alt="QNA3" width="1100px">
                     </div>
                     </div>
                 </div>
           
                 <div class="panel panel-default">
                      <div class="panel-heading">
                           <h2 class="panel-title">
                                 <a data-toggle="collapse" data-parent="#Main" href="#List5">필드에서 아이템이 사라졌습니다.</a>
                           </h2>
                     </div>

                     <div id="List5" class="panel-collapse collapse">
                     <div class="panel-body">
                         <h5 class="text-default">필드에 아이템을 버릴 경우 일정시간 후 자동으로 사라지며, 교환불가 아이템의 경우에는 버리는 즉시 사라지게 됩니다.</h5>
                          <h5 class="text-default">상점에 판매한 아이템을 '재구매'탭에서 다시 구매하지 않은 상태로 채널 이동, 게임 종료 등이 이루어지면 마찬가지로 사라지게 됩니다.</h5>
                          <h5 class="text-default">이와 같은 경우 아이템 복구는 가능하지 않습니다.</h5><br>
                          <h5 class="text-danger">혹시, 회원님도 모르게 아이템이 사라졌다면 아래 기재사항을 적어 문의주세요.</h5>
                          <h5 class="text-default">적어주신 정보를 토대로 아이템이 어떻게 사라지게 되었는지 확인 후 안내해드리겠습니다.</h5><br>
                          <h5 class="text-default">[기재사항]</h5>
                          <h5 class="text-default">1. 월드/캐릭터명 :</h5>
                          <h5 class="text-default">2. 오류발생일시 :</h5>
                         <h5 class="text-default">3. 사라진 아이템명/골드 :</h5>
                         <h5 class="text-default">4. 자세한 상황설명 :</h5>
                     </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div><br>


    <!-- 고객센터 Container -->
    <div id="contact" class="container">
    <h2 style="color:#FFFFFF">고객문의</h2><h5><p class="text-danger">도움말로 해결되지 않으신다면 고객센터로 문의하실 수 있습니다.</h5></p>
    <br>
    <form class="form-horizontal" action="#" method="POST" name="login-form">
        <div class="form-group">
            <label for="ID2" class="control-label col-sm-2" for="ID" style="color:#FFFFFF">게임 ID :</label>
            <div class="col-sm-5">
                <!-- 같은 화면에서 AutoForcus 설정이 여러번 정의 될 경우 첫 번째 정의 된 곳으로 커서가 이동 2번째부터 무시 -->
                <input id="ID2" class="form-control" autocomplete="off" type=text size="25" placeholder="User ID" required name="username" autofocus>
            </div>
        </div>
        <div class="form-group">
            <label for="email" class="control-label col-sm-2" for="ID" style="color:#FFFFFF">답변받으실 E-mail :</label>
            <div class="col-sm-5">
                <input id="email" class="form-control" autocomplete="off" type=email size="25" placeholder="E-mail" required name="email" autofocus>
            </div>
        </div>
        <div class="form-group">
            <label for="CO" class="control-label col-sm-2" for="ID" style="color:#FFFFFF">Comment :</label> 
            <div class="col-sm-10"> 
            <textarea class="form-control" id="comments" maxlength="100" placeholder="Comment" rows="5" required autocomplete="off"></textarea>
            </div>
        </div>
        <div class="form-group">
            <div class="col-md-12 form-group">
            <button class="btn pull-right btn-default" type="submit">SEND</button>
            </div>
        </div>    
    </div>
    </form>
    </div>

    <!-- footer Container -->
    <footer style="background-color: #1d1d1d;" class="container text-center">
        <div id="STORE" class="container text-center" >
        <br><br>
        <span style="font-size:20px; color: #cacaca;" class="glyphicon glyphicon-earphone"></span><a href="./QNA2.php" class="btn" style="color: #cacaca;">고객문의</a></span>
        <div style = "text-align:center;margin-bottom:100px;">
        <br><br>

        <p style="color: #cacaca;"> 
            <i class="fa fa-instagram" aria-hidden="true" style="color: #cacaca;"></i> 인스타그램&nbsp;&nbsp;
            <i class="fa fa-twitter" aria-hidden="true"></i> 트위터&nbsp;&nbsp;&nbsp;
            <i class="fa fa-youtube-play" aria-hidden="true"></i> 유튜브 
        </p>
        <br><br>

        <div style="font-size:12pt;"> 
            <span><a href="#" class="btn" style="color: #cacaca;">회사소개</a></span> | 
            <span><a href="#" class="btn" style="color: #cacaca;">이용약관</a></span> | 
            <span><a href="#" class="btn" style="color: #cacaca;">개인정보처리방침</a></span> | 
            <span><a href="#" class="btn" style="color: #cacaca;">청소년 보호 정책</a></span> | 
            <span><a href="#" class="btn" style="color: #cacaca;">커뮤니티 정책</a></span> | 
            <span><a href="#" class="btn" style="color: #cacaca;">운영정책</a></span> 
        </div>
        
        <hr style="border: solid 1px rgb(146, 146, 146); width: 850px;">  

        <div style="margin-top:10pt; color: #cacaca;"> 
            <p><span>상호 (주) KGGAME 사업자 등록번호 123-45-67890 통신판매업신고 제 2021-서울종로-1234호 사업자정보확인
                <br>주소 서울 종로구 돈화문로 26 단성사 4층 고객상담 1234-5678 팩스 02-1234-5678 이메일 kggame@kggame.com
                <br>Copyright &copy; KGGAME Corporation. All Rights Reserved.</span></p>
                <br>        
        </div> 
    </div>
    </footer>

</body>
</html>


